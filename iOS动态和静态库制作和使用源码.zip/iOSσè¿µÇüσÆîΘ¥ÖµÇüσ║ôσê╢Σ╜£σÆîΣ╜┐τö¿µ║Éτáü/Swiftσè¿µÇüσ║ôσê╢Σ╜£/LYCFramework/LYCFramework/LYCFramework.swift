//
//  LYCFramework.swift
//  LYCFramework
//
//  Created by 史ios on 16/12/31.
//  Copyright © 2016年 李游城. All rights reserved.
//

import UIKit

open class LYCFramework: NSObject {
    
    static  let bundle = Bundle(for: LYCFramework.self);
    static let LYCFrameworkSTr = "fengjing";
    
    open static func openVCFromStoryboard(){
        let vc = UIStoryboard(name: "LYCFramework", bundle: bundle).instantiateViewController(withIdentifier: "LYCFrameworkViewController");
        
        //跳转
        UIApplication.shared.keyWindow?.rootViewController?.present(vc, animated: true, completion: { () -> Void in
            
        });
        
    }
    
    open static func openVCFromXib(){
        let vc = LYCFrameworkViewController(nibName: "LYCFramework", bundle: bundle);
        //跳转
        UIApplication.shared.keyWindow?.rootViewController?.present(vc, animated: true, completion: { () -> Void in
            
        });
        
    }
    
    //加载图片
    open static func loadImage() -> UIImage{
        let image = UIImage(named: LYCFrameworkSTr + ".jpeg", in: bundle, compatibleWith: nil);
        return image!;
    }
}
