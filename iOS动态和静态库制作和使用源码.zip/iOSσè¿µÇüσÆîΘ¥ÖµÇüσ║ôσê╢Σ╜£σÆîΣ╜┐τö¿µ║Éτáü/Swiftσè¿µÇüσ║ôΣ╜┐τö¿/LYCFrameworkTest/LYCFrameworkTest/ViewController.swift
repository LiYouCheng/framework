//
//  ViewController.swift
//  LYCFrameworkTest
//
//  Created by 史ios on 2016/12/31.
//  Copyright © 2016年 李游城. All rights reserved.
//

import UIKit

import LYCFramework

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func openXib(_ sender: Any) {
        LYCFramework.openVCFromXib();
    }

    
    @IBAction func openStoryboard(_ sender: Any) {
        LYCFramework.openVCFromStoryboard();
    }
    
    @IBAction func openImage(_ sender: Any) {
        let iamge = LYCFramework.loadImage();
        
        
//        print(<#T##items: Any...##Any#>)
        
        let libPath = "\(NSHomeDirectory())/Documents/LYCFramework.framework/MyFramework"
        if let bundle = Bundle(path: libPath) {
            do {
                try bundle.loadAndReturnError()
                if let lycFramework = NSClassFromString("LYCFramework") as?LYCFramework.Type {
                    
//                    lycFramework.initialize();
//                   lycFramework.initialize().whereIsFrom()
                }
            } catch {
                print("   ") }
        }
    }
}

