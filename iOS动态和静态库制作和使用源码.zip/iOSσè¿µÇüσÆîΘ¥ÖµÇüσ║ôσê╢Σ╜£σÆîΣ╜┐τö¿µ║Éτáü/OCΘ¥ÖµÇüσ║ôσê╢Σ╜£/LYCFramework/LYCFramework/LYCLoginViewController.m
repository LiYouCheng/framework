//
//  LYCLoginViewController.m
//  LYCFramework
//
//  Created by 史ios on 2016/12/31.
//  Copyright © 2016年 李游城. All rights reserved.
//

#import "LYCLoginViewController.h"

@interface LYCLoginViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *logoImageView;
@property (weak, nonatomic) IBOutlet UITextField *accountTextField;
@property (weak, nonatomic) IBOutlet UITextField *passwordTextField;
- (IBAction)clickedLogin:(id)sender;

@end

@implementation LYCLoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

- (void)refreshUI {
    
//    NSBundle *bundle = [NSBundle bundleForClass:[self class]];
    
    self.logoImageView.image = [UIImage imageNamed:@"fengjing.jpeg"];
    
    self.accountTextField.text = @"542235666@qq.com";
    self.passwordTextField.text = @"123456";
    
}

- (IBAction)clickedLogin:(id)sender {
    
    [self dismissViewControllerAnimated:YES completion:^{
        NSLog(@"登陆成功");
    }];
    
}
@end
