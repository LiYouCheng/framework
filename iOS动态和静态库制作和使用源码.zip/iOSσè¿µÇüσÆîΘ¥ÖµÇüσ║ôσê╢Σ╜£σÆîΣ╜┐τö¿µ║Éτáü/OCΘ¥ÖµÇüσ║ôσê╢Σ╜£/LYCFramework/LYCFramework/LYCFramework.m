//
//  LYCFramework.m
//  LYCFramework
//
//  Created by 史ios on 2016/12/31.
//  Copyright © 2016年 李游城. All rights reserved.
//

#import "LYCFramework.h"

#import "LYCLoginViewController.h"

@implementation LYCFramework

+ (void)enterLogin {
    
    NSBundle *bundle = [NSBundle bundleForClass:[LYCFramework class]];//动态库需要
//    myFramework/LYCLoginViewController 静态库需要
    
    LYCLoginViewController *vc = [[LYCLoginViewController alloc] initWithNibName:@"myFramework/LYCLoginViewController" bundle:nil];
    [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:vc animated:YES completion:^{
        
    }];
}

@end
