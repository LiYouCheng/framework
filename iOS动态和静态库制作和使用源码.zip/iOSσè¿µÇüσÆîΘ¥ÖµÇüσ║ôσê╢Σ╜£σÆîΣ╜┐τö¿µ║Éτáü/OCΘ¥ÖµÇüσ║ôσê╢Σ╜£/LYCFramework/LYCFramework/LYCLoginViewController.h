//
//  LYCLoginViewController.h
//  LYCFramework
//
//  Created by 史ios on 2016/12/31.
//  Copyright © 2016年 李游城. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LYCLoginViewController : UIViewController

@end
