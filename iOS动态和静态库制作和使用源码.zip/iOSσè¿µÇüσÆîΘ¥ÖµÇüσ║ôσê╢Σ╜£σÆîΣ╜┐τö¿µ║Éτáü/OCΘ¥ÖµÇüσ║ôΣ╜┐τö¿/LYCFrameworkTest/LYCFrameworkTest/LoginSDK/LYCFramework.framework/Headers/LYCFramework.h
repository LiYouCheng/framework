//
//  LYCFramework.h
//  LYCFramework
//
//  Created by 史ios on 2016/12/31.
//  Copyright © 2016年 李游城. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LYCFramework : NSObject

/**
 进入登陆界面 静态
 */
+ (void)enterLogin;

@end
